<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Home Service | <?php echo e($title); ?></title>
  </head>
  <body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
  <div class="container">
  <img src="<?php echo e(URL::asset('assets//img/logo.png')); ?>" alt=" " width=" " height="100" class="d-inline-block align-text-top">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  </div>
</nav>

<div class="container mt-4">
    <h1>Formulir Pemesanan</h1>
</div>

<div class="row justify-content-center">
  <div class="col-md-4">
   <main class="form-pesan w-100 m-auto">
    <h1 class="h3 mb-3 fw-normal text-center">Silahkan diisi</h1>
    <form>
       <div class="form-floating">
        <input type="nama" class="form-control" id="floatingInput" placeholder="Nama">
        <label for="floatingInput">Nama</label>
       </div>
       <div class="form-floating">
        <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
        <label for="floatingInput">Email</label>
       </div>
       <div class="form-floating">
         <input type="no_telepon" class="form-control" id="floatingInput" placeholder="No_Telepon">
         <label for="floatingInput">No Telepon</label>
       </div>
    </form>
    <small class="d-block text-center mt-3">Dengan memilih "Pesan" Anda menyatakan setuju dengan Ketentuan dan Biaya Pemesanan</small>
 </main>
    <a <button type="button" class="btn btn-warning" href="/terimakasih">Pesan</button></a>
</div>
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


  </body>
</html><?php /**PATH C:\Users\Public\INFORMATIKA\sem4\LAB PBW\belajar_laravel\resources\views/pesan.blade.php ENDPATH**/ ?>