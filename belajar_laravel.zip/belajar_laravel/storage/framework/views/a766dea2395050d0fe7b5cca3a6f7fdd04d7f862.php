<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  
    <title>Home Service | <?php echo e($title); ?></title>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
  <div class="container">
  <img src="<?php echo e(URL::asset('assets//img/logo.png')); ?>" alt=" " width=" " height="100" class="d-inline-block align-text-top">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link"  href="/art">ART</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/baby_sitter">Baby Sitter</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/perawat_lansia">Perawat Lansia</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/profil">Profil</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-4">
    <h1>Pesanan</h1>
</div>

<div class="dropdown" style="margin: 50px 1300px">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-bs-toggle="dropdown" aria-expanded="false"></button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
    <a <button class="dropdown-item" type="button">Pesanan</button></a>
    <a <button class="dropdown-item" type="button">Edit</button></a>
    <a <button class="dropdown-item" type="button" href="/">Keluar</button></a>
  </ul>
</div>

<div class="container" style="margin-top:20px">
  <div class="row">
    <div class="col-sm-4">
    <img src="<?php echo e(URL::asset('assets//img/profil.png')); ?>" alt=" " width=" " height="200" class="d-inline-block align-text-top">
      <h2>Sarmita</h2>
      <p>Profesi: <button type="button" class="btn btn-warning">ART</button></p>
      <button type="button" class="btn btn-danger">Rp. 30.000,00/jam</button>
    </div>
  </div>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


  </body>
</html><?php /**PATH C:\Users\Public\INFORMATIKA\sem4\LAB PBW\belajar_laravel\resources\views/pesanan.blade.php ENDPATH**/ ?>