<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home', [
        "title" => "Home"
    ]);
});

Route::get('/art', function () {
    return view('art', [
        "title" => "ART"
    ]);
});

Route::get('/baby_sitter', function () {
    return view('baby_sitter', [
        "title" => "Baby Sitter"
    ]);
});

Route::get('/perawat_lansia', function () {
    return view('perawat_lansia', [
        "title" => "Perawat Lansia"
    ]);
});

Route::get('/daftar', function () {
    return view('daftar', [
        "title" => "Daftar"
    ]);
});

Route::get('/profil', function () {
    return view('profil', [
        "title" => "Profil"
    ]);
});


Route::get('/masuk', function () {
    return view('masuk', [
        "title" => "Masuk"
    ]);
});

Route::get('/pesan', function () {
    return view('pesan', [
        "title" => "Pesan"
    ]);
});

Route::get('/terimakasih', function () {
    return view('terimakasih', [
        "title" => "Terimakasih"
    ]);
});

Route::get('/pesanan', function () {
    return view('pesanan', [
        "title" => "Pesanan"
    ]);
});


Route::get('/masuk', [LoginController::class, 'index']);
Route::get('/daftar', [RegisterController::class, 'index']);
